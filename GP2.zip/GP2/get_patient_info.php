<?php
session_start();

// Check if the National ID is provided via POST request
if (isset($_POST['nid'])) {
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "ADPrediction";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $email = $_SESSION['email'];
    $query = "SELECT physiologistId FROM physiologist WHERE email='$email'";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc(); // Fetch the row from the result
        $phys = $row['physiologistId']; // Get the value of 'physiologistId' column
        $nid = $_POST['nid']; // National ID provided via POST request

        $sql = "SELECT CONCAT(FirstName, ' ', LastName) AS FullName, Gender FROM patient WHERE PatientID = '$nid' AND physiologist='$phys'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // If patient found, fetch the name and gender
            $row = $result->fetch_assoc();
            $response = array(
                "FullName" => $row["FullName"],
                "Gender" => $row["Gender"]
            );

            echo json_encode($response);
        } else {
            echo json_encode(array("error" => "ID does not exist or you are not authorized to view this patient."));
        }
    } else {
        echo json_encode(array("error" => "Physiologist does not exist."));
    }

    // Close connection
    $conn->close();
} else {
    echo json_encode(array("error" => "National ID is not set."));
}
?>
