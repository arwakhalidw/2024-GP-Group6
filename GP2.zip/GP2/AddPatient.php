<?php
ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
session_start();

// Check if the user is logged in and their role is physiologist
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'physiologist') {
    echo '<script>alert("You are not authorized to access this page."); window.location.href = "index.php";</script>';
    exit; 
}
?>
<!DOCTYPE html>

<html lang="en" class="light-style layout-menu-fixed layout-compact" dir="ltr" data-theme="theme-default" data-assets-path="assets/" data-template="vertical-menu-template-free">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Home</title>

    <meta name="description" content="" />


    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />

    <link rel="stylesheet" href="assets/vendor/boxicons/css/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/perfect-scrollbar.scss" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/helpers.js"></script>
    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets/js/config.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>

<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->

            <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                <div class="app-brand demo">
                    <a href="physHP.php" class="app-brand-link">
                        <span class="app-brand-logo demo">
                            <a href="physHP.php"><img src="assets/img/homelogo.png" alt="" class="img-fluid" width="80"></a>
                        </span>
                        <span class="app-brand-text demo menu-text fw-bold ms-2" style=" text-transform: none;">DiA</span>
                    </a>

                    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
                        <i class="bx bx-chevron-left bx-sm align-middle"></i>
                    </a>
                </div>

                <div class="menu-inner-shadow"></div>

                <ul class="menu-inner py-1">

                    <!-- profile -->
                    <li class="menu-item active open">
                        <a href="physHP.php" class="menu-link">
                            <i class="menu-icon tf-icons bx bx-home-circle"></i>
                            <div data-i18n="Dashboards">Dashboard</div>
                        </a>
                    </li>
                    <li class="menu-item">
                        <a href="physProfile.php" class="menu-link ">
                            <i class="menu-icon tf-icons bx bx-user"></i>
                            <div data-i18n="Users">Profile</div>
                        </a>
                    </li>


                    <li class="menu-header small text-uppercase">
                        <span class="menu-header-text">our services</span>
                    </li>

                    <!-- services -->
                    <li class="menu-item">
                        <a href="Compare.php" class="menu-link ">
                            <i class="menu-icon tf-icons bx bx-git-compare"></i>
                            <div data-i18n="Compare">Compare AI Models</div>
                        </a>
                    </li>

                    <li class="menu-header small text-uppercase">
                        <span class="menu-header-text">other</span>
                    </li>

                    <!-- other -->
                    <li class="menu-item">
                        <a href="physLogout.php" class="menu-link ">
                            <i class="menu-icon tf-icons bx bx-power-off me-2"></i>
                            <div data-i18n="LogOut">Log Out</div>
                        </a>
                    </li>
                </ul>
            </aside>
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->

                    <div class="container-xxl flex-grow-1 container-p-y">
                        <!-- Layout Demo -->
                        <div class="layout-demo-wrapper">
                            <div class="layout-demo-placeholder">

                            </div>

                            <div class="layout-demo-info">

                            </div>
                        </div>
                        <!--/ Layout Demo -->

                        <!-- Basic Layout -->
                        <div class="row">
                            <div class="col-xl">
                                <div class="card mb-4">
                                    <div class="card-header d-flex justify-content-between align-items-center">
                                        <h5 class="mb-0">Add a Patient</h5>
                                    </div>
                                    <hr class="my-0">
                                    <div class="card-body">
                                        <form id="addForm" action="AddPatient.php" method="POST">
                                            <div class="mb-3">
                                                <label class="form-label" for="nid">Patient's ID</label>
                                                <input type="text" class="form-control" id="nid" name="nid" placeholder="Enter patient's ID" maxlength="10" minlength="10"onkeypress="return event.charCode >= 48 && event.charCode <= 57" pattern="^[0-9]*$" required />
                                                <div class="form-text"> You can use digits</div>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="firstName" class="form-label">First Name</label>
                                                <input class="form-control" type="text" id="firstName" name="firstName" placeholder="Enter first name" pattern="[A-Za-z]+" onkeypress="return (event.charCode >= 65 && event.charCode <= 90) || (event.charCode >= 97 && event.charCode <= 122)" required />
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="lastName" class="form-label">Last Name</label>
                                                <input class="form-control" type="text" name="lastName" id="lastName" placeholder="Enter last name" pattern="[A-Za-z]+" onkeypress="return (event.charCode >= 65 && event.charCode <= 90) || (event.charCode >= 97 && event.charCode <= 122)" required />
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label class="form-label" for="tel">Phone Number</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text">SA (+966)</span>
                                                    <input type="text" id="tel" name="tel" class="form-control" placeholder="532 023 481" required />
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="gender" class="form-label">Gender</label>
                                                <select class="form-select" name="gender" id="gender" required>
                                                    <option value="male">Male</option>
                                                    <option value="female">Female</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label for="dob" class="col-md-2 col-form-label">Date Of Birth</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="date" name="dob" id="dob" required/>
                                                </div>
                                            </div>
                                            <div class="mb-3 col-md-6">
                                                <label for="age" class="form-label">Age</label>
                                                <input class="form-control" type="text" id="age" name="age" required/>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Add</button>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
					
					    <script>
        $(document).ready(function(){
            $('#dob').on('change', function(){
                var dob = $(this).val();
                var today = new Date();
                var birthDate = new Date(dob);
                var age = today.getFullYear() - birthDate.getFullYear();
                var m = today.getMonth() - birthDate.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                    age--;
                }
                $('#age').val(age);
            });
        });
    </script>
                    <!-- / Content -->
                     <?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "ADPrediction";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" ) {
   
    // Retrieve form data
    $PID=$_POST["nid"];
    $first_name = $_POST["firstName"];
    $last_name = $_POST["lastName"];
    $dob = $_POST["dob"];
	$age=$_POST["age"];
	$tel = "+966" . ltrim($_POST["tel"], '0');
    $gender = $_POST["gender"]; // Retrieve gender value
    $email=$_SESSION['email'];
   $check_sql = "SELECT * FROM patient WHERE PatientID='$PID'";
    $result = $conn->query($check_sql);
     if ($result->num_rows > 0) {
        // User already exists
       echo '<script>alert("User already exists");</script>';
     }else{
        $er="SELECT physiologistId FROM physiologist where email='$email'";
         $r = $conn->query($er);
if ($r->num_rows > 0) {
    $row = $r->fetch_assoc(); // Fetch the row from the result
    $physiologistId = $row['physiologistId']; // Get the value of 'physiologistId' column
    // Insert data into database
    $sql = "INSERT INTO patient (PatientID,FirstName, LastName, DOB, phoneNo, Age, Gender, physiologist) VALUES ('$PID','$first_name', '$last_name', '$dob', '$tel', $age, '$gender', $physiologistId)";
    if ($conn->query($sql) === TRUE) {
        echo '<script>alert("New record created successfully");</script>';
    } else {
        echo '<script>alert("Sorry we cannot create new record, Try again ");</script>';
    }
} else {
    echo '<script>alert("Physiologist not found");</script>';
}

}
}
// Close connection
$conn->close();
?>

                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                            <div class="mb-2 mb-md-0">
                                &copy; Copyright DiA. All Rights Reserved
                            </div>
                            <div class="d-none d-lg-inline-block">
                                <a href="contact.php" target="_blank" class="footer-link">Contact</a>
                            </div>
                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- / Layout wrapper -->
    </div>

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->

    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/perfect-scrollbar.js"></script>
    <script src="assets/js/menu.js"></script>

    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="assets/js/main2.js"></script>

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
</body>

</html>