<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check if the user is logged in and their role is physiologist
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'physiologist') {
    echo '<script>alert("You are not authorized to access this page."); window.location.href = "index.php";</script>';
    exit;
}

// Proceed with displaying the profile page for physiologists
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "ADPrediction";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Could not connect to the database");
	
									
}

?>
<!DOCTYPE html>

<html lang="en" class="light-style layout-menu-fixed layout-compact" dir="ltr" data-theme="theme-default" data-assets-path="assets/" data-template="vertical-menu-template-free">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Predict Alzheimer’s</title>

    <meta name="description" content="" />


    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />

    <link rel="stylesheet" href="assets/vendor/boxicons/css/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/perfect-scrollbar.scss" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/helpers.js"></script>
    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets/js/config.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	
	<script>
    
		$(document).ready(function() {
    var nid = $('input[name=nid]').val(); // Get the National ID from session variable
    if (nid) {
        // AJAX request to fetch patient's name and gender
        $.ajax({
            type: 'POST',
            url: 'get_patient_info.php',
            data: { nid: nid },
            success: function(response) {
                var data = JSON.parse(response);
                if (data.error) {
                    $('input[name=name]').val(data.error);
                    $('input[name=gender]').val(data.error);
                } else {
                    $('input[name=name]').val(data.FullName); // Update the patient's name field
                    $('input[name=gender]').val(data.Gender); // Update the patient's gender field
                }
            },
            error: function(xhr, status, error) {
                alert('Error occurred while fetching patient\'s name and gender.');
            }
        });
    }
});


	</script>
</head>

<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->

            <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                <div class="app-brand demo">
                    <a href="physHP.php" class="app-brand-link">
                        <span class="app-brand-logo demo">
                            <a href="physHP.php"><img src="assets/img/homelogo.png" alt="" class="img-fluid" width="80"></a>
                        </span>
                        <span class="app-brand-text demo menu-text fw-bold ms-2" style=" text-transform: none;">DiA</span>
                    </a>

                    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
                        <i class="bx bx-chevron-left bx-sm align-middle"></i>
                    </a>
                </div>

                <div class="menu-inner-shadow"></div>

                <ul class="menu-inner py-1">

                    <!-- profile -->
                    <li class="menu-item">
                        <a href="physHP.php" class="menu-link">
                            <i class="menu-icon tf-icons bx bx-home-circle"></i>
                            <div data-i18n="Dashboards">Dashboard</div>
                        </a>
                    </li>
                    <li class="menu-item">
                        <a href="physProfile.php" class="menu-link ">
                            <i class="menu-icon tf-icons bx bx-user"></i>
                            <div data-i18n="Users">Profile</div>
                        </a>
                    </li>


                    <li class="menu-header small text-uppercase">
                        <span class="menu-header-text">our services</span>
                    </li>

                    <!-- services -->
                    <li class="menu-item">
                        <a href="Compare.php" class="menu-link ">
                            <i class="menu-icon tf-icons bx bx-git-compare"></i>
                            <div data-i18n="Compare">Compare AI Models</div>
                        </a>
                    </li>

                    <li class="menu-header small text-uppercase">
                        <span class="menu-header-text">other</span>
                    </li>

                    <!-- other -->
                    <li class="menu-item">
                        <a href="physphysLogout.php" class="menu-link ">
                            <i class="menu-icon tf-icons bx bx-power-off me-2"></i>
                            <div data-i18n="LogOut">Log Out</div>
                        </a>
                    </li>
                </ul>
            </aside>
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->

                    <div class="container-xxl flex-grow-1 container-p-y">
                        <!-- Layout Demo -->
                        <div class="layout-demo-wrapper">
                            <div class="layout-demo-placeholder">

                            </div>

                            <div class="layout-demo-info">

                            </div>
                        </div>
                        <!--/ Layout Demo -->

                        <!-- Basic Layout -->
                        <div class="row">
                            <div class="col-xl">
                                <div class="card mb-4">
                                    <div class="card-header d-flex justify-content-between align-items-center">
                                        <h5 class="mb-0">Predict Alzheimer’s</h5>
                                    </div>
                                    <hr class="my-0">
                                    <div class="card-body">
                                        <form action="prediction.php" method="POST">
                                            <div class="mb-3">
                                                <label class="form-label" for="nid">Patient's ID</label>
                                                <input type="text" class="form-control" id="nid" name="nid" placeholder="Enter patient's ID" value="<?php echo isset($_SESSION['PatientID']) ? $_SESSION['PatientID'] : ''; ?>" maxlength="10" readonly>
                                                
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label" for="name">Patient's Name</label>
                                                <input type="text" class="form-control" id="name" name="name" value="" readonly />
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label" for="cdr">CDR score</label>
                                                <input type="number" id="cdr" name="cdr" class="form-control" placeholder="Enter patient's CDR" required step="0.5" min="0" max="3" pattern="\d+(\.\d+)?" required />
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label" for="basic-default-phone">MMSE score</label>
                                                <input type="number" id="mmse" name="mmse" class="form-control phone-mask" placeholder="Enter patinet's score" min="0" max="30" required />
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label" for="nWBV">nWBV</label>
                                                <input type="number" id="nWBV" name="nWBV" class="form-control phone-mask" placeholder="Enter patient's nWBV" required step="0.01" />
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label" for="educ">Years of Education</label>
                                                <input type="number" id="educ" name="educ" class="form-control phone-mask" placeholder="Enter patient's years of education" required />
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label" for="gender">Patient's Gender</label>
                                                <input type="text" class="form-control" id="gender" name="gender" value="" readonly />
                                            </div>
                                            <button type="submit" class="btn btn-primary">Predict</button>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                        <!-- / Content -->

                        <!-- Footer -->
                        <footer class="content-footer footer bg-footer-theme">
                            <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                                <div class="mb-2 mb-md-0">
                                    &copy; Copyright DiA. All Rights Reserved
                                </div>
                                <div class="d-none d-lg-inline-block">
                                    <a href="contact.php" target="_blank" class="footer-link">Contact</a>
                                </div>
                            </div>
                        </footer>
                        <!-- / Footer -->

                        <div class="content-backdrop fade"></div>
                    </div>
                    <!-- Content wrapper -->
                </div>
                <!-- / Layout page -->
            </div>

            <!-- / Layout wrapper -->
        </div>

        <!-- Core JS -->
        <!-- build:js assets/vendor/js/core.js -->

        <script src="assets/js/jquery.js"></script>
        <script src="assets/js/popper.js"></script>
        <script src="assets/js/bootstrap.js"></script>
        <script src="assets/js/perfect-scrollbar.js"></script>
        <script src="assets/js/menu.js"></script>

        <!-- endbuild -->

        <!-- Vendors JS -->

        <!-- Main JS -->
        <script src="assets/js/main2.js"></script>

        <!-- Page JS -->

        <!-- Place this tag in your head or just before your close body tag. -->
        <script async defer src="https://buttons.github.io/buttons.js"></script>
</body>

</html>