import os
from flask import Flask, request, jsonify
import openai
from dotenv import load_dotenv
from datetime import datetime
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Load environment variables from .env file
load_dotenv()

# Set OpenAI API key
openai.api_key = os.getenv('OPENAI_API_KEY')

# Store user sessions to track progress
user_sessions = {}

# Define the 6 CDR categories and number of questions per category
CDR_CATEGORIES = ["Memory", "Orientation", "Judgment and Problem Solving", 
                  "Community Affairs", "Home and Hobbies", "Personal Care"]
QUESTIONS_PER_CATEGORY = 5  # We will ask 5 questions per category

@app.route('/chatbot', methods=['POST'])
def chatbot():
    user_input = request.json['message']
    patient_id = request.json['patient_id']  # Patient ID should be provided in the request

    # Initialize session for new users
    if patient_id not in user_sessions:
        user_sessions[patient_id] = {
            'current_question': 0,
            'current_category_index': 0,  # Track the category index
            'in_examination': False,
            'confirmed_information': False,  # Track if patient info has been confirmed
            'patient_name': None,  # Store the patient's first name
            'answers': [],  # Track user answers
            'evaluations': [],  # To store the category scores
        }

    # Fetch the session for this patient
    session_data = user_sessions[patient_id]

    # Confirm patient information before starting the examination
    if not session_data['confirmed_information']:
        return handle_confirmation(user_input, session_data, patient_id)

    # Handle the user's response to start the examination
    if user_input.lower() == "yes" and not session_data['in_examination']:
        session_data['in_examination'] = True
        return start_examination(session_data)

    # If user is in the examination, process their answers
    if session_data['in_examination']:
        return handle_user_answer(user_input, session_data)

    # Respond with a general message if not in the examination
    return jsonify({"message": "Please confirm your details or start the examination."})


def handle_confirmation(user_input, session_data, patient_id):
    if user_input.lower() == "yes":
        session_data['confirmed_information'] = True
        return jsonify({"message": "Great! Now we can begin the examination. Are you ready to start?"})
    elif user_input.lower() == "no":
        return jsonify({"message": "Please verify your details and try again."})
    else:
        return confirm_patient_information(patient_id)


def confirm_patient_information(patient_id):
    # Mocked patient information (since DB connection isn't needed anymore)
    patient_data = {
        'FirstName': 'John',
        'LastName': 'Doe',
        'dob': '01/01/1950',
        'gender': 'Male'
    }

    if patient_data:
        # Store patient's name in session
        user_sessions[patient_id]['patient_name'] = patient_data['FirstName']

        # Construct a message to confirm the patient's information
        confirmation_message = (f"Please confirm your information:\n"
                                f"First Name: {patient_data['FirstName']}\n"
                                f"Last Name: {patient_data['LastName']}\n"
                                f"Date of Birth: {patient_data['dob']}\n"
                                f"Gender: {patient_data['gender']}\n"
                                "Is this information correct? (yes/no)")

        return jsonify({"message": confirmation_message})
    else:
        return jsonify({"message": "Patient ID not found. Please provide a valid Patient ID."})


def start_examination(session_data):
    # Start with the first category
    session_data['category'] = CDR_CATEGORIES[session_data['current_category_index']]
    session_data['current_question'] = 0  # Reset question index for each category
    response_message = ask_question(session_data)

    return jsonify({"message": response_message})


def handle_user_answer(user_input, session_data):
    current_question_index = session_data['current_question']
    category = session_data['category']

    # Store the user's current answer
    session_data['answers'].append(user_input)

    # Check if the current category's 5 questions have been asked
    if current_question_index + 1 < QUESTIONS_PER_CATEGORY:
        session_data['current_question'] += 1
        next_question = ask_question(session_data)
        return jsonify({"message": next_question})
    else:
        # Evaluate the current category after 5 questions
        evaluation_message = evaluate_category(session_data)
        session_data['evaluations'].append(evaluation_message)

        # Move to the next category if any remain
        session_data['current_category_index'] += 1
        if session_data['current_category_index'] < len(CDR_CATEGORIES):
            session_data['category'] = CDR_CATEGORIES[session_data['current_category_index']]
            session_data['current_question'] = 0  # Reset for the new category
            session_data['answers'] = []  # Clear previous answers for the new category
            question_message = ask_question(session_data)
            return jsonify({
                "message": f"The score for this category is: {evaluation_message}.<br>Now moving on to the {session_data['category']} category.<br>{question_message}",
            })
        else:
            # All categories have been completed
            return jsonify({"message": "You have completed all the questions. Thank you!"})


def ask_question(session_data):
    patient_name = session_data['patient_name']
    category = session_data['category']
    current_question_index = session_data['current_question']
    
    today_date = datetime.now().strftime("%d/%m/%Y")
    
    # Prepare a prompt for GPT to generate a question from the current category
    prompt = (
        "No meta-phrasing. "
        f"You are a doctor John Morris conducting a Clinical Dementia Rating (CDR) examination for patient {patient_name}. "
        f"Today’s date is {today_date}. You are now assessing the {category} category. "
        f"This is question {current_question_index + 1} out of 5 for this category. "
        "Generate a question related to this category that helps evaluate the patient's cognitive abilities."
    )
    
    # Call GPT API
    gpt_response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "assistant", "content": prompt}]
    )

    # Return the GPT-generated question
    return gpt_response['choices'][0]['message']['content'].strip()


def evaluate_category(session_data):
    patient_name = session_data['patient_name']
    category = session_data['category']
    
    # Get all answers provided by the patient for the current category
    answers = session_data['answers']
    today_date = datetime.now().strftime("%d/%m/%Y")

    # Prepare the prompt for GPT to evaluate the category based on patient's answers
    prompt = (
        "No meta-phrasing. "
        f"Today's date is {today_date}. "
        f"As Doctor John Morris you are evaluating the Clinical Dementia Rating (CDR) of patient {patient_name}, "
        f"you are assessing the {category} category. The patient's answers were: {', '.join(answers)}. "
        "Evaluate these responses and assign a score for this category based on the patient's performance. "
        "Output the score for the category without any additional text."
    )
    
    # Call GPT API
    gpt_response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )
    
    # Return the GPT-generated evaluation and score for the category
    return gpt_response['choices'][0]['message']['content'].strip()


if __name__ == '__main__':
    app.run(debug=True)
