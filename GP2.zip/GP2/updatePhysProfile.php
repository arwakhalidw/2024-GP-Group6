<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'physiologist') {
    echo '<script>alert("You are not authorized to access this page."); window.location.href = "index.php";</script>';
    exit; 
}

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "ADPrediction";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user inputs
    $fullName = $_POST['fullName'];
    $password = $_POST['password'];
	$newEmail = $_POST['email'];
    $oldEmail = $_SESSION['email'];
	


    // Prepare and bind the statement
    $stmt = $conn->prepare("UPDATE physiologist SET name=?, password=?, email=? WHERE email=?");
    $stmt->bind_param('ssss', $fullName, $password, $newEmail, $oldEmail);

    // Execute the statement
    if ($stmt->execute()) {
            $_SESSION['email'] = $newEmail;
            echo '<script>alert("Profile updated successfully."); window.location.href = "physProfile.php";</script>';
        } else {
            echo '<script>alert("Error updating profile: Email Already Exists"); window.location.href = "physProfile.php";</script>';
        }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
