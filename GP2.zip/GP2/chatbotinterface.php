<?php
session_start();

// Check if the user is logged in and their role is patient
				if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') {
				echo '<script>alert("You are not authorized to access this page."); window.location.href = "index.php";</script>';
			    exit; 
									}
									
									
?>
<!DOCTYPE html>
<html lang="en" class="light-style layout-menu-fixed layout-compact" dir="ltr" data-theme="theme-default" data-assets-path="assets/" data-template="vertical-menu-template-free">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
  <title>DiA Chatbot</title>
  <meta name="description" content="" />

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@300;400;500;600&display=swap" rel="stylesheet" />

  <!-- Icons -->
  <link rel="stylesheet" href="assets/vendor/boxicons/css/boxicons.css" />

  <!-- Core CSS -->
  <link rel="stylesheet" href="assets/vendor/core.css" class="template-customizer-core-css" />
  <link rel="stylesheet" href="assets/vendor/theme-default.css" class="template-customizer-theme-css" />
  <link rel="stylesheet" href="assets/css/demo.css" />

  <!-- Vendors CSS -->
  <link rel="stylesheet" href="assets/perfect-scrollbar.scss" />
  <link rel="stylesheet" href="assets/vendor/apex-charts.css" />

  <!-- Additional Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined&family=Material+Symbols+Rounded&display=swap" />

  <!-- JS Helpers -->
  <script src="assets/vendor/helpers.js"></script>
  <script src="assets/js/config.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
  .chatbox {
    border: 1px solid #463dc5;
    border-radius: 5px;
    background: #fff;
    max-width: 900px;
	height: 400px;
    margin: 20px auto;
    display: flex;
    flex-direction: column;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  .chatbox-header {
    background: #463dc5;
    color: black;
    padding: 10px;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
  }

  .chatbox-body {
    flex: 1;
    padding: 10px;
    overflow-y: auto;
    max-height: 300px;
  }

  .message {
    margin: 5px 0;
  }

  .bot-message {
    color: #463dc5;
  }

  .user-message {
    text-align: right;
    color: #1c1036;
  }

  .chatbox-footer {
    display: flex;
    padding: 10px;
    border-top: 1px solid #ccc;
  }

  .chatbox-footer input {
    flex: 1;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-right: 5px;
  }

  .chatbox-footer button {
    padding: 10px;
    border: none;
    background: #463dc5;
    color: #fff;
    border-radius: 5px;
    cursor: pointer;
  }
</style>

  

<script>
$(document).ready(function () {
  const chatInput = $('#userInput');
  const chatbox = $('.chatbox-body');
  const sendBtn = $('#sendMessage');
  const patientId = '<?php echo $_SESSION["PID"]; ?>';
  const initialMessage = "Hello. This is DiA's CDR chatbot. To start the examination, type 'Start'.";

  // Load messages from local storage
  function loadMessages() {
    const messages = JSON.parse(localStorage.getItem('chatMessages')) || [];
    messages.forEach(message => {
      addMessage(message.text, message.type);
    });
  }

  // Save messages to local storage
  function saveMessages(message, type) {
    const messages = JSON.parse(localStorage.getItem('chatMessages')) || [];
    messages.push({ text: message, type: type });
    localStorage.setItem('chatMessages', JSON.stringify(messages));
  }

  function addMessage(message, type = 'outgoing') {
    const messageHTML = `
      <div class="message ${type === 'incoming' ? 'bot-message' : 'user-message'}">
        ${type === 'incoming' ? '<span class="material-symbols-outlined">smart_toy</span>' : ''}
        <p>${message}</p>
      </div>`;
    chatbox.append(messageHTML);
    chatbox.scrollTop(chatbox[0].scrollHeight);
    // Save message to local storage
    saveMessages(message, type === 'incoming' ? 'incoming' : 'outgoing');
  }

  function sendMessage() {
    const userMessage = chatInput.val().trim();
    if (!userMessage) return;

    addMessage(userMessage, 'outgoing');
    chatInput.val('');

    $.ajax({
      url: 'http://127.0.0.1:5000/chatbot',
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({ message: userMessage, patient_id: patientId }),
      success: function (response) {
        if (response.message) {
          addMessage(response.message, 'incoming');
        }
      },
      error: function (jqXHR) {
        console.error("Error:", jqXHR.responseText);
        addMessage("Sorry, there was an error.", 'incoming');
      }
    });
  }

  // Load messages on page load
  loadMessages();

  // Check if the chat has been initialized; if not, add the initial message
  const messages = JSON.parse(localStorage.getItem('chatMessages')) || [];
  if (messages.length === 0) {
    addMessage(initialMessage, 'incoming');
  }

  sendBtn.on('click', sendMessage);

  chatInput.on('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });
});


</script>

</head>

<body>
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
      <aside id="layout-menu" class="layout-menu menu-vertical bg-menu-theme">
        <div class="app-brand demo">
          <a href="patientHP.php" class="app-brand-link">
            <img src="assets/img/homelogo.png" alt="logo" class="img-fluid" width="80">
           <span class="app-brand-text demo menu-text fw-bold ms-2" style=" text-transform: none;">DiA</span>
          </a>
        </div>
        <div class="menu-inner-shadow"></div>
        <ul class="menu-inner py-1">
          <li class="menu-item">
            <a href="patientHP.php" class="menu-link">
              <i class="menu-icon bx bx-home-circle"></i>
              <div>Dashboard</div>
            </a>
          </li>
          <li class="menu-item">
            <a href="patientProfile.php" class="menu-link">
              <i class="menu-icon bx bx-user"></i>
              <div>Profile</div>
            </a>
          </li>
		  <li class="menu-header small text-uppercase">
            <span class="menu-header-text">our services</span>
          </li>

          <li class="menu-item active open">
            <a href="chatbotinterface.php" class="menu-link">
              <i class="menu-icon bx bx-cube-alt"></i>
              <div>DiA Chatbot</div>
            </a>
          </li>
		   <li class="menu-header small text-uppercase">
            <span class="menu-header-text">other</span>
          </li>
          <li class="menu-item">
            <a href="patientLogout.php" class="menu-link">
              <i class="menu-icon bx bx-power-off me-2"></i>
              <div>Log Out</div>
            </a>
          </li>
        </ul>
      </aside>

      <div class="layout-page">
        <div class="content-wrapper">
          <div class="container-xxl flex-grow-1 container-p-y">
           <div class="chatbox" id="chatbox">
        <div class="chatbox-header">
          <h4 style="text-align: center; color: white;">Smart CDR Diagnosis Tool</h4>

        </div>
        <div class="chatbox-body" id="chatboxBody">
        </div>
        <div class="chatbox-footer">
          <input type="text" id="userInput" placeholder="Type your message..." />
          <button id="sendMessage">Send</button>
        </div>
      </div>
    </div>
          </div>

          <footer class="content-footer footer bg-footer-theme">
            <div class="container-xxl d-flex justify-content-between py-2">
              <span>&copy; Copyright DiA. All Rights Reserved</span>
              <a href="contact.php" target="_blank" class="footer-link">Contact</a>
            </div>
          </footer>
        </div>
      </div>
    </div>
  </div>

  <!-- Core JS -->
  <script src="assets/js/jquery.js"></script>
  <script src="assets/js/popper.js"></script>
  <script src="assets/js/bootstrap.js"></script>
  <script src="assets/js/perfect-scrollbar.js"></script>
  <script src="assets/js/menu.js"></script>
  <script src="assets/js/main2.js"></script>
</body>
</html>
