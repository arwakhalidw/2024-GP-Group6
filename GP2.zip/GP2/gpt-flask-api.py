import os
import re
from flask import Flask, request, jsonify
import openai
from dotenv import load_dotenv
import mysql.connector
from datetime import datetime
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Load environment variables from .env file
load_dotenv()

# Set OpenAI API key
openai.api_key = os.getenv('OPENAI_API_KEY')

# Establish database connection
db_connection = mysql.connector.connect(
    host=os.getenv('DB_HOST'),
    user=os.getenv('DB_USER'),
    password=os.getenv('DB_PASSWORD'),
    database=os.getenv('DB_NAME')
)

# Store user sessions to track progress
user_sessions = {}

@app.route('/chatbot', methods=['POST'])
@app.route('/chatbot', methods=['POST'])
def chatbot():
    user_input = request.json['message']
    patient_id = request.json['patient_id']  # Patient ID should be provided in the request

    # Initialize session for new users
    if patient_id not in user_sessions:
        user_sessions[patient_id] = {
            'current_question': 0,
            'questions': [],
            'category': None,
            'in_examination': False,
            'confirmed_information': False,  # Track if patient info has been confirmed
            'patient_name': None,
            'city': None,
            'patient_id': None,
            'patient_dob': None,   
            'answers': [],  # track user answers
            'evaluations': [], # to store the category scores
        }

    # Fetch the session for this patient
    session_data = user_sessions[patient_id]

    # Ask for the patient's current city if not already provided
    if session_data['city'] is None:
        if 'city_prompted' not in session_data:
            session_data['city_prompted'] = True
            return jsonify({"message": "Before we begin, could you please tell me which city the patient is currently in?"})
        else:
            session_data['city'] = user_input
            confirm_patient_information(patient_id, session_data)

    # Confirm patient information before starting the examination
    if not session_data['confirmed_information']:
        return handle_confirmation(user_input, session_data, patient_id)

    # Handle the user's response to start the examination
    if user_input.lower() == "yes" and not session_data['in_examination']:
        session_data['in_examination'] = True
        return start_examination(session_data)

    # If user is in the examination, process their answers
    if session_data['in_examination']:
        return handle_user_answer(user_input, session_data)

    # Respond with a general message if not in the examination
    return jsonify({"message": "Please confirm the details or start the examination."})



def handle_confirmation(user_input, session_data, patient_id):
    if user_input.lower() == "yes":
        session_data['confirmed_information'] = True
        return jsonify({"message": "Great! Now we can begin the examination. Are you ready to start?"})
    elif user_input.lower() == "no":
        return jsonify({"message": "Please verify the details and try again."})
    else:
        return confirm_patient_information(patient_id,session_data)


def confirm_patient_information(patient_id, session_data):
    cursor = db_connection.cursor(dictionary=True)
    
    # Fetch patient details from the database using patient ID
    cursor.execute("SELECT PatientID, FirstName, LastName, DOB, Gender FROM patient WHERE PatientID = %s", (patient_id,))
    patient_data = cursor.fetchone()
    cursor.close()

    if patient_data:
        # Store patient's name in session
        user_sessions[patient_id]['patient_name'] = patient_data['FirstName']
        user_sessions[patient_id]['patient_dob'] = patient_data['DOB']
        user_sessions[patient_id]['patient_id'] = patient_data['PatientID']

        # Construct a message to confirm the patient's information
        confirmation_message = (f"Please confirm the patient's information:<br>"
                                f"First Name: {patient_data['FirstName']}<br>"
                                f"Last Name: {patient_data['LastName']}<br>"
                                f"Date of Birth: {patient_data['DOB']}<br>"
                                f"Gender: {patient_data['Gender']}<br>"
                                f"The city the patient is currently in: {session_data['city']}<br>"
                                "Is this information correct? (yes/no)")

        return jsonify({"message": confirmation_message})
    else:
        return jsonify({"message": "Patient ID not found. Please provide a valid Patient ID."})


def start_examination(session_data):
    # Retrieve questions from the database if not already loaded
    if not session_data['questions']:
        cursor = db_connection.cursor(dictionary=True)
        cursor.execute("SELECT Question, Category FROM CDR_Questions ORDER BY Question_No ASC")
        session_data['questions'] = cursor.fetchall()
        cursor.close()

    # Set the first category and question
    session_data['category'] = session_data['questions'][0]['Category']
    response_message = ask_question(session_data)

    return jsonify({"message": f"First, let's start with {session_data['category']} category.<br> Disclaimer: This section should be answered by the patient. If the patient is unable to write or lacks technological skills, the caregiver should type in the answers. To get accurate assessment, please make sure to write the patient's responses as accurately as possible. <br> {response_message}"})


# Define a function to check if the user's response is relevant
def check_relevance(question, user_response, session_data):

      if session_data['category'] in ['Memory', 'Orientation', 'Judgment and Problem Solving']:
        prompt = (
            "No meta-phrasing."
            "You are a physiologist assessing a patient's responses for a clinical dementia examination. "
            "Here is their answer to the following question:\n\n"
            f"Question: {question}\n"
            f"Response: {user_response}\n\n"
            "Answer does not need to be correct, it must however be relevant to the question."
            "Determine whether the patient's response is relevant to the question."
            "Reply with 'Relevant' if the answer is related to the question, and 'Not Relevant' otherwise."
            
        )

        # Call GPT API to assess relevance
        gpt_response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[{"role": "assistant", "content": prompt}]
        ) 

        # Extract and return the assessment result
        relevance_assessment = gpt_response['choices'][0]['message']['content'].strip()
        print(relevance_assessment)

        return relevance_assessment
        
      else:
        prompt = (
            "No meta-phrasing."
            "You are a physiologist assessing a patient's responses for a clinical dementia examination. "
            "Here is their answer to the following question:\n\n"
            f"Question: {question}\n"
            f"Response: {user_response}\n\n"
            "The answer does not need to be correct but should be considered relevant if it attempts to address the question's topic or context. "
            "Reply with 'Relevant' if the response relates to the question, even if incorrect, and 'Not Relevant' otherwise."
        )


        # Call GPT API to assess relevance
        gpt_response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[{"role": "assistant", "content": prompt}]
        ) 

        # Extract and return the assessment result
        relevance_assessment = gpt_response['choices'][0]['message']['content'].strip()

        return relevance_assessment

def handle_user_answer(user_input, session_data):
    current_question_index = session_data['current_question']

    
    # Get the current question
    current_question = session_data['questions'][current_question_index]['Question']
    category = session_data['questions'][current_question_index]['Category']

    # Check if the user's answer is relevant to the current question
    relevance = check_relevance(current_question, user_input, session_data)

    if relevance == "Relevant":
        # Store the user's current answer
        session_data['answers'].append(user_input)
        
        # Save the response to the database
        cursor = db_connection.cursor()
        insert_query = """
            INSERT INTO user_responses (patientID, question, response, category)
            VALUES (%s, %s, %s, %s)
        """
        cursor.execute(insert_query, (session_data['patient_id'], current_question, user_input, category))
        db_connection.commit()
        cursor.close()

        # Check if there are more questions in this category
        if current_question_index + 1 < len(session_data['questions']):
            # Move to the next question
            session_data['current_question'] += 1
            next_question = session_data['questions'][session_data['current_question']]
            
            if next_question['Category'] != session_data['category']:
                # Evaluate the current category
                evaluation_message = evaluate_category(session_data)
                session_data['evaluations'].append(evaluation_message)
                evaluation_array = [re.sub(r'[^0-9\.]', '', item) for item in session_data['evaluations']]
                numeric_arr = [float(item) for item in evaluation_array]
                print("Evaluations Array:", session_data['evaluations'])
                print("Evaluations Array:", numeric_arr)
                
                ## SEND ARRAY TO MODEL
                
                
                # Update to the new category
                session_data['category'] = next_question['Category']
                session_data['answers'] = []  # Reset answers for the new category
                
                # Start the new category with the first question
                question_message = ask_question(session_data)
                
                # Check if the new category should be answered by the patient or caregiver
                if session_data['category'] in ['Memory', 'Orientation', 'Judgment and Problem Solving']:
                    return jsonify({
                        "message": f"Now moving on to the {session_data['category']} category. <br> Disclaimer: This section should be answered by the patient. If the patient is unable to write or lacks technological skills, the caregiver should type in the answers. To get an accurate assessment, please make sure to write the patient's responses as accurately as possible. <br>{question_message}",
                    })
                else:
                    return jsonify({
                        "message": f"Now moving on to the {session_data['category']} category. <br> This section should be answered by the caregiver. <br>{question_message}",
                    })
            else:
                # Continue in the same category
                return jsonify({"message": ask_question(session_data)})

        # If this is the last question in the category and no more questions left overall
        else:
            # Evaluate the last category
            evaluation_message = evaluate_category(session_data)
            session_data['evaluations'].append(evaluation_message)
            
            evaluation_array = [re.sub(r'[^0-9\.]', '', item) for item in session_data['evaluations']]
            numeric_arr = [float(item) for item in evaluation_array]
            print("Evaluations Array:2", session_data['evaluations'])
            
            # Final message as there are no more questions
            return jsonify({"message": "You have completed all the questions and evaluations. Thank you!"})

    else:
        retry_question = ask_question(session_data)
        # Ask the user to provide a relevant answer again
        return jsonify({"message": f"Your response doesn't seem relevant to the question. Could you try again? {retry_question}"})






def ask_question(session_data):
    patient_name = session_data['patient_name']
    current_question_index = session_data['current_question']
 
    
    if current_question_index < len(session_data['questions']):
        current_question = session_data['questions'][current_question_index]['Question']
        category = session_data['category']
        
        today_date = datetime.now().strftime("%d/%m/%Y")
        
        if session_data['category'] in ['Memory', 'Orientation', 'Judgment and Problem Solving']:
            prompt = (
                "No meta-phrasing."
                f"You are a physiologist. You are asking questions from the {category} category to a patient named {patient_name}. "
                f"for their Clinical Dementia Rating (CDR) examination. Today's date is {today_date}. "
                f"Please ask the following question to the patient: '{current_question}'. "    
            )
            
            # Call GPT API
            gpt_response = openai.ChatCompletion.create(
                model="gpt-4o-mini",
                messages=[{"role": "assistant", "content": prompt}]
            )

            # Return the GPT-generated question to ask the patient
            return gpt_response['choices'][0]['message']['content'].strip()
            
        else:
            prompt = (
                "No meta-phrasing."
                f"You are a physiologist. You are asking questions from the {category} category to the caregiver of a patient named {patient_name}."
                f"for their Clinical Dementia Rating (CDR) examination. Today's date is {today_date}. "
                f"Please ask the following question to the caregiver: '{current_question}'. "    
            )
            
            # Call GPT API
            gpt_response = openai.ChatCompletion.create(
                model="gpt-4o-mini",
                messages=[{"role": "assistant", "content": prompt}]
            )

            # Return the GPT-generated question to ask the patient
            return gpt_response['choices'][0]['message']['content'].strip()

    return "No more questions in this category."


def evaluate_category(session_data):
    patient_name = session_data['patient_name']
    category = session_data['category']
    dob = session_data['patient_dob']
    
    # Get all answers provided by the patient for the current category
    answers = session_data['answers']
    questions = [q['Question'] for q in session_data['questions'] if q['Category'] == category]
    today_date = datetime.now().strftime("%d/%m/%Y")

    if session_data['category'] in ['Memory', 'Orientation', 'Judgment and Problem Solving']:

        prompt = (
            "No meta-phrasing."
            f"Today's date is {today_date}."
            f"As a physiologist evaluating the Clinical Dementia Rating (CDR) of patient {patient_name}. {patient_name} date of birth is {dob}. They are currently in the city of {session_data['city']}"
            f"you asked {patient_name} the following questions from the {category} category: "
            f"{', '.join(questions)}. "
            f"The patient's answers were: {', '.join(answers)}. "
            f"Internally, evaluate these responses. Then assign a score for the category based on the patient's performance. Output the score without any additional text."
        )
        
        # Call GPT API
        gpt_response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}]
        )
        
        # Return the GPT-generated evaluation and score for the category
        return gpt_response['choices'][0]['message']['content'].strip()
    
    else:
        prompt = (
            "No meta-phrasing."
            f"Today's date is {today_date}."
            f"As a physiologist evaluating the Clinical Dementia Rating (CDR) of patient {patient_name}, "
            f"you asked their caregiver the following questions from the {category} category: "
            f"{', '.join(questions)}. "
            f"The caregiver's answers were: {', '.join(answers)}. "
            f"Internally, evaluate these responses. Then assign a score for the category based on the patient's performance. Output the score."
        )
        
        # Call GPT API
        gpt_response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}]
        )
        
        # Return the GPT-generated evaluation and score for the category
        return gpt_response['choices'][0]['message']['content'].strip()
    


if __name__ == '__main__':
    app.run(debug=True)