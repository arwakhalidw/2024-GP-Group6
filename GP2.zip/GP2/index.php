<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>DiA - Landing</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: SoftLand
  * Template URL: https://bootstrapmade.com/softland-bootstrap-app-landing-page-template/
  * Updated: Mar 17 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex justify-content-between align-items-center">

      <div class="logo">
        <a href="index.php"><img src="assets/img/Brain_Chat_logo_brain_bubble_chat_logo-removebg-preview.png" alt="" class="img-fluid"></a>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="#about">About</a></li>
          <li><a href="#mission">Mission</a></li>
          <li class="dropdown"><a href="#"><span>Join Today</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="patientJoin.php">Patient</a></li>
              <li><a href="physiologistJoin.php">Physiologist</a></li>
            </ul>
          </li>
          <li><a href="#articles">Articles</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section class="hero-section" id="hero">

    <div class="wave">

      <svg width="100%" height="355px" viewBox="0 0 1920 355" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
          <g id="Apple-TV" transform="translate(0.000000, -402.000000)" fill="#FFFFFF">
            <path d="M0,439.134243 C175.04074,464.89273 327.944386,477.771974 458.710937,477.771974 C654.860765,477.771974 870.645295,442.632362 1205.9828,410.192501 C1429.54114,388.565926 1667.54687,411.092417 1920,477.771974 L1920,757 L1017.15166,757 L0,757 L0,439.134243 Z" id="Path"></path>
          </g>
        </g>
      </svg>

    </div>

    <div class="container">
      <div class="row align-items-center">
        <div class="col-12 hero-text-image">
          <div class="row">
            <div class="col-lg-8 text-center text-lg-start">
              <h1 data-aos="fade-right">Alzheimer's Predictor</h1>
              <p class="mb-5" data-aos="fade-right" data-aos-delay="100">Streamlining Alzheimer's Prediction: Just a Few Clicks Away</p>
              <p data-aos="fade-right" data-aos-delay="200" data-aos-offset="-500"><a href="#about" class="btn btn-outline-white">Get started</a></p>
            </div>
            <div class="col-lg-4 iphone-wrap">
              <img src="assets/img/file.png" alt="Image" class="phone-1" data-aos="fade-right">
            </div>
          </div>
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Home Section ======= -->
    <section class="section" id="about">
      <div class="container">

        <div class="row justify-content-center text-center mb-5">
          <div class="col-md-5" data-aos="fade-up">
            <h2 class="section-heading">Why DiA?</h2>
          </div>
        </div>

        <div class="row">
          <div class="col-md-4" data-aos="fade-up" data-aos-delay="">
            <div class="feature-1 text-center">
              <div class="wrap-icon icon-1">
                <i class="bi bi-people"></i>
              </div>
              <h3 class="mb-3">Exploring consultations</h3>
              <p>View all of your consultation results.</p>
            </div>
          </div>
          <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
            <div class="feature-1 text-center">
              <div class="wrap-icon icon-1">
                <i class="bi bi-brightness-high"></i>
              </div>
              <h3 class="mb-3">Digital Dashboard</h3>
              <p>view your very own Dashboard.</p>
            </div>
          </div>
          <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
            <div class="feature-1 text-center">
              <div class="wrap-icon icon-1">
                <i class="bi bi-bar-chart"></i>
              </div>
              <h3 class="mb-3">Tracking Progress</h3>
              <p>Track the progress of Alzheimer's Disease.</p>
            </div>
          </div>
        </div>

      </div>
    </section>
    <hr>
    <section class="section">

      <div class="container" style=" margin-left: 24%;">

        <div class="row">
          <div class="col-md-4">
            <div class="step">
              <span class="number">01</span>
              <h3>Join us</h3>
              <p>Register your account.</p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="step">
              <span class="number">02</span>
              <h3>Unleash features</h3>
              <p>seize unlimited features.</p>
            </div>
          </div>
        </div>
        <br>

        <div class="row justify-content-center text-center mb-5" data-aos="fade">
          <div class="col-md-6 mb-5" style=" margin-right: 26%;">
            <img src="assets/img/features.svg" alt="Image" class="img-fluid"> 
          </div>
        </div>
      </div>

    </section>
   <hr>
    <section class="section" style="padding-left: 9%;" id="mission">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-4 me-auto">
            <h2 class="mb-4">Seamlessly Predict</h2>
            <p class="mb-4">our cutting-edge prediction model revolutionizes decision-making. With our advanced algorithms and user-friendly interface, predicting future outcomes has never been easier. Whether healthcare, or beyond, our seamless prediction platform empowers you to make informed choices with confidence. Join the countless users already benefiting from our innovative technology and unlock the power of predictive analytics today.</p>
            <p><a href="#about" class="btn btn-primary">Join Us</a></p>
          </div>
          <div class="col-md-6" data-aos="fade-left">
            <img src="assets/img/details-3.png" alt="Image" height="650 px" >
          </div>
        </div>
      </div>
    </section>

    <section class="section" style="padding-left: 6%;">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-4 ms-auto order-2">
            <h2 class="mb-4">Review History</h2>
            <p class="mb-4">we empower our users to Review the Progress of tests like CDR and MMSE. By combining predictive analytics with the ability to monitor cognitive health assessments, we provide a comprehensive solution for proactive decision-making and personalized care. Join us today and take control of your cognitive health tracking with ease.</p>
            <p><a href="#about" class="btn btn-primary">Join Us</a></p>
          </div>
          <div class="col-md-6" data-aos="fade-right">
            <img src="assets/img/details-4.png" alt="Image" height="650 px" >
          </div>
        </div>
      </div>
    </section>
    <div class="swiper-pagination"></div>

   <!-- ======= Testimonials Section ======= -->
    <section class="section border-top border-bottom" id="articles">
      <div class="container">
        <div class="row justify-content-center text-center mb-5">
          <div class="col-md-4">
            <h2 class="section-heading">Articles</h2>
          </div>
        </div>
        <div class="row justify-content-center text-center">
          <div class="col-md-7">

            <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
              <div class="swiper-wrapper">

                <div class="swiper-slide">
                  <div class="review text-center">
                    <a href="https://www.nia.nih.gov/health/alzheimers-and-dementia/alzheimers-disease-fact-sheet" style="text-decoration: underline;"><h3>Alzheimer's Disease Fact Sheet</h3></a>
                    <blockquote>
                      <p>Abstract: Alzheimer’s disease is a brain disorder that slowly destroys memory and thinking skills, and eventually, the ability to carry out the simplest tasks. In most people with Alzheimer’s, symptoms first appear later in life. Estimates vary, but experts suggest that more than 6 million Americans, most of them age 65 or older, may have Alzheimer’s.</p>
                    </blockquote>

                    <p class="review-user">
                      <img src="assets/img/national-institute-on-aging-logo.png" alt="Image" class="img-fluid rounded-circle mb-3">
                      <span class="d-block">
                        <span  class="text-black">National Institute On Aging</span>
                      </span>
                    </p>

                  </div>
                </div>

                <div class="swiper-slide">
                  <div class="review text-center">
                    <a href="https://www.cdc.gov/aging/aginginfo/alzheimers.htm" style="text-decoration: underline;"><h3>Alzheimer’s Disease and Related Dementias</h3></a>
                    <blockquote>
                      <p>Abstract: Death rates for Alzheimer’s disease are increasing, unlike heart disease and cancer death rates that are on the decline.5 Dementia, including Alzheimer’s disease, has been shown to be under-reported in death certificates and therefore the proportion of older people who die from Alzheimer’s may be considerably higher.</p>
                    </blockquote>

                    <p class="review-user">
                      <img src="assets/img/images.png" alt="Image" class="img-fluid rounded-circle mb-3">
                      <span class="d-block">
                        <span class="text-black">centers for disease control</span>
                      </span>
                    </p>

                  </div>
                </div>

                <div class="swiper-slide">
                  <div class="review text-center">
                    <a href="https://my.clevelandclinic.org/health/diseases/9164-alzheimers-disease" style="text-decoration: underline;"><h3>Alzheimer’s Disease</h3></a>
                    <blockquote>
                      <p>Abstract: Alzheimer’s disease causes a decline in memory, thinking, learning and organizing skills over time. It’s the most common cause of dementia and usually affects people over the age of 65. There’s no cure for Alzheimer’s, but certain medications and therapies can help manage symptoms temporarily.</p>
                    </blockquote>

                    <p class="review-user">
                      <img src="assets/img/Cleveland-Clinic-Symbol.png" alt="Image" class="img-fluid rounded-circle mb-3">
                      <span class="d-block">
                        <span class="text-black">cleveland clinic</span>
                      </span>
                    </p>

                  </div>
                </div>

              </div>
              <div class="swiper-pagination"></div>
            </div>
          </div>
        </div>
      </div>
    </section> <!-- End Testimonials Section --> 

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer class="footer" role="contentinfo">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-4 mb-md-0">
          <h3>About DiA</h3>
          <p>Empowering Early Prediction & Driving Change for Alzheimer's. 
            Our platform utilizes advanced models for early Alzheimer detection. 
            And a user-friendly chatbot interface for the Clinical Dementia Rating (CDR) test, 
            DiA is committed to proactive cognitive health management, making a difference in Alzheimer's care.</p>
        </div>
        <div class="col-md-7 ms-auto">
          <div class="row site-section pt-0">
            <div class="col-md-4 mb-4 mb-md-0">
              <h3>Navigation</h3>
              <ul class="list-unstyled">
                <li><a href="#about">About</a></li>
                <li><a href="#mission">Mission</a></li>
                <li><a href="#articles">Articles</a></li>
              </ul>
            </div>
            <div class="col-md-4 mb-4 mb-md-0">
              <h3>Services</h3>
              <ul class="list-unstyled">
                <li><a href="services.php">CDR diagnosis chatbot</a></li>
                <li><a href="services.php">Alzheimer’s Predictor</a></li>
                <li><a href="contact.php">Contact</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div class="row justify-content-center text-center">
        <div class="col-md-7">
          <p class="copyright">&copy; Copyright DiA. All Rights Reserved</p>
          <div class="credits">   
          </div>
        </div>
      </div>

    </div>
  </footer>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>