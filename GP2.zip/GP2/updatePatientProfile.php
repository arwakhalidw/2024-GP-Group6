<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') {
    echo '<script>alert("You are not authorized to access this page."); window.location.href = "index.php";</script>';
    exit; 
}

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "ADPrediction";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user inputs
    $firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
    $NewPhoneNo = "+966" . ltrim($_POST["tel"], '0');
    $PID = $_SESSION['PID'];
	


    // Prepare and bind the statement
    $stmt = $conn->prepare("UPDATE patient SET FirstName=?, LastName=?, phoneNo=? WHERE PatientID=?");
    $stmt->bind_param('ssss', $firstName, $lastName, $NewPhoneNo, $PID);

    // Execute the statement
    if ($stmt->execute()) {
            $_SESSION['phone'] = $NewPhoneNo;
            echo '<script>alert("Profile updated successfully."); window.location.href = "patientProfile.php";</script>';
        } else {
            echo '<script>alert("Error updating profile: phone number already registered."); window.location.href = "patientProfile.php";</script>';
        }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
