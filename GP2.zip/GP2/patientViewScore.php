<!DOCTYPE html>

<html lang="en" class="light-style layout-menu-fixed layout-compact" dir="ltr" data-theme="theme-default" data-assets-path="assets/" data-template="vertical-menu-template-free">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

  <title>Home</title>

  <meta name="description" content="" />


  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />

  <link rel="stylesheet" href="assets/vendor/boxicons/css/boxicons.css" />

  <!-- Core CSS -->
  <link rel="stylesheet" href="assets/vendor/core.css" class="template-customizer-core-css" />
  <link rel="stylesheet" href="assets/vendor/theme-default.css" class="template-customizer-theme-css" />
  <link rel="stylesheet" href="assets/css/demo.css" />

  <!-- Vendors CSS -->
  <link rel="stylesheet" href="assets/perfect-scrollbar.scss" />

  <!-- Page CSS -->

  <!-- Helpers -->
  <script src="assets/vendor/helpers.js"></script>
  <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
  <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
  <script src="assets/js/config.js"></script>
</head>

<body>
  <!-- Layout wrapper -->
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
      <!-- Menu -->

      <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
        <div class="app-brand demo">
          <a href="index.php" class="app-brand-link">
            <span class="app-brand-logo demo">
              <a href="index.php"><img src="assets/img/homelogo.png" alt="" class="img-fluid" width="80"></a>
            </span>
            <span class="app-brand-text demo menu-text fw-bold ms-2" style=" text-transform: none;">DiA</span>
          </a>

          <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
          </a>
        </div>

        <div class="menu-inner-shadow"></div>

        <ul class="menu-inner py-1">
          <!-- profile -->
          <li class="menu-item active open">
            <a href="patientHP.php" class="menu-link">
              <i class="menu-icon tf-icons bx bx-home-circle"></i>
              <div data-i18n="Dashboards">Dashboard</div>
            </a>
          </li>
          <li class="menu-item">
            <a href="patientProfile.php" class="menu-link">
              <i class="menu-icon tf-icons bx bx-user"></i>
              <div data-i18n="Users">Profile</div>
            </a>
          </li>


          <li class="menu-header small text-uppercase">
            <span class="menu-header-text">our services</span>
          </li>

          <!-- services -->
          <li class="menu-item">
            <a href="chatbotinterface.php" class="menu-link ">
              <i class="menu-icon tf-icons bx bx-cube-alt"></i>
              <div data-i18n="Predict">DiA Chatbot</div>
            </a>
          </li>

          <li class="menu-header small text-uppercase">
            <span class="menu-header-text">other</span>
          </li>

          <!-- other -->
          <li class="menu-item">
            <a href="javascript:void(0);" class="menu-link ">
              <i class="menu-icon tf-icons bx bx-power-off me-2"></i>
              <div data-i18n="LogOut">Log Out</div>
            </a>
          </li>
        </ul>
      </aside>
      <!-- / Menu -->

      <!-- Layout container -->
      <div class="layout-page">
        <!-- Content wrapper -->
        <div class="content-wrapper">
          <!-- Content -->

          <div class="container-xxl flex-grow-1 container-p-y">
            <!-- Layout Demo -->
            <div class="layout-demo-wrapper">
              <div class="layout-demo-placeholder">

              </div>

              <div class="layout-demo-info">

              </div>
            </div>
            <!--/ Layout Demo -->

            <!-- Striped Rows -->
            <div class="card">
              <h5 class="card-header">CDR Score Details</h5>
              <hr class="my-0">
              <div class="table-responsive text-nowrap">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>Measure</th>
                      <th>Answer</th>
                      <th>Score</th>
                    </tr>
                  </thead>
                  <tbody class="table-border-bottom-0">
                    <tr>
                      <th>Memory</th>
                      <td>No memory loss</td>
                      <td>0</td>
                    
                      <tr style="background-color: white;"> 
                        <td>Q1</td>
                        <td>A1</td>
                        <td>-</td>
                      </tr>
                      <tr style="background-color: white;"> 
                        <td>Q2</td>
                        <td>A2</td>
                        <td>-</td>
                      </tr>
                    </tr>
                    <tr>
                      <th>Orientation</th>
                      <td>Fully Oriented</td>
                      <td>0</td>
                      <tr style="background-color: white;"> 
                        <td>Q1</td>
                        <td>A1</td>
                        <td>-</td>
                      </tr>
                      <tr style="background-color: white;"> 
                        <td>Q2</td>
                        <td>A2</td>
                        <td>-</td>
                      </tr>
                    </tr>
                    <tr>
                      <th>Judgment And Problem Solving</th>
                      <td>Slight Impairment in solving problems</td>
                      <td>0</td>
                      <tr style="background-color: white;"> 
                        <td>Q1</td>
                        <td>A1</td>
                        <td>-</td>
                      </tr>
                      <tr style="background-color: white;"> 
                        <td>Q2</td>
                        <td>A2</td>
                        <td>-</td>
                      </tr>
                    </tr>
                    <tr>
                      <th>Community Affairs</th>
                      <td>Slight impairment in these activites</td>
                      <td>0.5</td>
                      <tr style="background-color: white;"> 
                        <td>Q1</td>
                        <td>A1</td>
                        <td>-</td>
                      </tr>
                      <tr style="background-color: white;"> 
                        <td>Q2</td>
                        <td>A2</td>
                        <td>-</td>
                      </tr>
                    </tr>
                    <tr>
                      <th>Home And Hbbies</th>
                      <td> Well maintained</td>
                      <td>0</td>

                      <tr style="background-color: white;"> 
                        <td>Q1</td>
                        <td>A1</td>
                        <td>-</td>
                      </tr>
                      <tr style="background-color: white;"> 
                        <td>Q2</td>
                        <td>A2</td>
                        <td>-</td>
                      </tr>

                    </tr>
                    <tr>
                      <th>Personal Care</th>
                      <td>fully capable of self care</td>
                      <td>0</td>

                      <tr style="background-color: white;"> 
                        <td>Q1</td>
                        <td>A1</td>
                        <td>-</td>
                      </tr>
                      <tr style="background-color: white;"> 
                        <td>Q2</td>
                        <td>A2</td>
                        <td>-</td>
                      </tr>

                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

          </div>
          <!-- / Content -->

          <!-- Footer -->
          <footer class="content-footer footer bg-footer-theme">
            <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
              <div class="mb-2 mb-md-0">
                &copy; Copyright DiA. All Rights Reserved
              </div>
              <div class="d-none d-lg-inline-block">
                <a href="contact.php" target="_blank" class="footer-link">Contact</a>
              </div>
            </div>
          </footer>
          <!-- / Footer -->

          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->
      </div>
      <!-- / Layout page -->
    </div>

    <!-- / Layout wrapper -->
  </div>

  <!-- Core JS -->
  <!-- build:js assets/vendor/js/core.js -->

  <script src="assets/js/jquery.js"></script>
  <script src="assets/js/popper.js"></script>
  <script src="assets/js/bootstrap.js"></script>
  <script src="assets/js/perfect-scrollbar.js"></script>
  <script src="assets/js/menu.js"></script>

  <!-- endbuild -->

  <!-- Vendors JS -->

  <!-- Main JS -->
  <script src="assets/js/main2.js"></script>

  <!-- Page JS -->

  <!-- Place this tag in your head or just before your close body tag. -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
</body>

</html>