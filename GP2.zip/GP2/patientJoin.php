<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve Patient ID and Phone Number from the form submission
    $pid = strtolower($_POST['patientid'] ?? '');
    $phoneNo = $_POST['pno'] ?? '';

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "ADPrediction";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Validate login for patient
    $sql_patient = "SELECT * FROM patient WHERE PatientID='$pid' AND phoneNo='$phoneNo'";
    $result_patient = mysqli_query($conn, $sql_patient);

    if (mysqli_num_rows($result_patient) == 1) {
        $row = mysqli_fetch_assoc($result_patient);
        if ($pid === $row['PatientID'] && $phoneNo === $row['phoneNo']) {
            $_SESSION['PID'] = $pid;
            $_SESSION['role'] = 'patient';
			$_SESSION['phone'] = $phoneNo;
            header ("Location: patientHP.php");
            exit;
        }
    }

    echo '<script>alert("Ensure that phone and ID is correct.");</script>';
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>DiA - Login</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans|Poppins" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style2.css" rel="stylesheet">

    <script type="module">
        // Import Firebase modules
        import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js';
        import { getAuth, RecaptchaVerifier, signInWithPhoneNumber } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js';

        const firebaseConfig = {
            apiKey: "AIzaSyB9Ja-wx53MqTYZhjAYRoRxENa-vDhc_mc",
            authDomain: "authentication-74d68.firebaseapp.com",
            projectId: "authentication-74d68",
            storageBucket: "authentication-74d68.appspot.com",
            messagingSenderId: "913458525286",
            appId: "1:913458525286:web:2f1521a6ca0cd4edbda9a7",
            measurementId: "G-EHR36FLPJ4"
        };

        const app = initializeApp(firebaseConfig);
        const auth = getAuth(app);
        let confirmationResult;

        window.sendOTP = function() {
            const phoneNumber = document.getElementById('PNO').value;
            const patientId = document.getElementById('patientID').value;

            const appVerifier = new RecaptchaVerifier('recaptcha-container', {
                'size': 'invisible'
            }, auth);

            signInWithPhoneNumber(auth, phoneNumber, appVerifier)
                .then((result) => {
                    confirmationResult = result;
                    document.getElementById('credentials-window').style.display = 'none'; 
                    document.getElementById('otp-window').style.display = 'block'; 
                    console.log("OTP sent successfully!");
                    alert("OTP was sent to phone number.");

                    // Set hidden input values
                    document.getElementById('hiddenPatientID').value = patientId;
                    document.getElementById('hiddenPhoneNo').value = phoneNumber;
                })
                .catch((error) => {
                    console.error("Error during sending OTP:", error);
                    alert("An error occurred during sending the OTP. Try again later.");
                    appVerifier.clear();
                });
        }

        window.verifyOTP = function() {
            const otp = document.getElementById('otp').value;
            confirmationResult.confirm(otp)
                .then((result) => {
                    console.log("User signed in successfully!");
                    document.getElementById('otp-window').style.display = 'none'; 
                    document.getElementById('credentials-window').style.display = 'block'; 


                    // Submit the form with hidden fields
                    document.getElementById('patientLoginOTP').submit();
                })
                .catch((error) => {
                    console.error("Error during OTP verification:", error);
                    alert("The OTP you entered is incorrect. Please try again.");
                });
        }
    </script>
</head>

<body>
<main>
    <div class="container">
        <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">
                        <div class="d-flex justify-content-center py-4">
                            <a href="index.php" class="logo d-flex align-items-center w-auto">
                                <img src="assets/img/logo.png" alt="">
                                <span class="d-none d-lg-block">DiA</span>
                            </a>
                        </div>

                        <div class="card mb-3" id="credentials-window">
                            <div class="card-body">
                                <div class="pt-4 pb-2">
                                    <h5 class="card-title text-center pb-0 fs-4">Login to Your Account</h5>
                                    <p class="text-center small">Enter your Patient ID & Phone number to login</p>
                                </div>

                                <form method="POST" id="patientLogin" class="row g-3 needs-validation" onsubmit="return false;">
                                    <div class="col-12">
                                        <label for="patientID" class="form-label">Patient ID</label>
                                        <div class="input-group has-validation">
                                            <input type="text" name="patientid" class="form-control" id="patientID" pattern="[0-9]{10}" required>
                                            <div class="invalid-feedback">Please enter your Patient ID.</div>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <label for="PNO" class="form-label">Phone Number</label>
                                        <input type="tel" name="pno" class="form-control" id="PNO" placeholder="+12345678900" required>
                                        <div class="invalid-feedback">Please enter your Phone Number!</div>
                                    </div>

                                    <div class="col-12">
                                        <button id="send-otp" style="border-color: rgb(92, 57, 205); background-color: rgb(92, 57, 205);" class="btn btn-primary w-100" type="button" onclick="sendOTP();">Send OTP</button>
                                    </div>

                                    <div class="col-12">
                                        <p class="small mb-0">Are you a physiologist? <a href="physiologistJoin.php">Physiologist Account</a></p>
                                    </div>
                                    <div id="recaptcha-container"></div>
                                </form>
                            </div>
                        </div>

                        <div id="otp-window" class="card mb-3" style="display: none;">
                            <div class="card-body">
                                <div class="pt-4 pb-2">
                                    <h5 class="card-title text-center pb-0 fs-4">OTP</h5>
                                </div>

                                <form method="POST" id="patientLoginOTP" class="row g-3 needs-validation" onsubmit="return false;">
                                    <input type="hidden" name="patientid" id="hiddenPatientID">
                                    <input type="hidden" name="pno" id="hiddenPhoneNo">
                                    
                                    <div class="col-12" id="otp-section">
                                        <label for="otp" class="form-label">Enter the OTP number</label>
                                        <input type="text" id="otp" name="otp" class="form-control" required>
                                        <div class="col-12">
                                            <button id="verify-otp" style="border-color: rgb(92, 57, 205); background-color: rgb(92, 57, 205);" class="btn btn-primary w-100" type="button" onclick="verifyOTP();">Login</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</main>

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script>

</body>
</html>
