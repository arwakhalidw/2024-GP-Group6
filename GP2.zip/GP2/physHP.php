<?php
session_start();

// Check if the user is logged in and their role is physiologist
				if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'physiologist') {
				echo '<script>alert("You are not authorized to access this page."); window.location.href = "index.php";</script>';
			    exit; 
									}
?>


<!DOCTYPE html>

<html lang="en" class="light-style layout-menu-fixed layout-compact" dir="ltr" data-theme="theme-default" data-assets-path="assets/" data-template="vertical-menu-template-free">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

  <title>Home</title>

  <meta name="description" content="" />


  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />

  <link rel="stylesheet" href="assets/vendor/boxicons/css/boxicons.css" />

  <!-- Core CSS -->
  <link rel="stylesheet" href="assets/vendor/core.css" class="template-customizer-core-css" />
  <link rel="stylesheet" href="assets/vendor/theme-default.css" class="template-customizer-theme-css" />
  <link rel="stylesheet" href="assets/css/demo.css" />

  <!-- Vendors CSS -->
  <link rel="stylesheet" href="assets/perfect-scrollbar.scss" />

  <!-- Page CSS -->

  <!-- Helpers -->
  <script src="assets/vendor/helpers.js"></script>
  <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
  <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
  <script src="assets/js/config.js"></script>
</head>

<body>
  <!-- Layout wrapper -->
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
      <!-- Menu -->

      <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
        <div class="app-brand demo">
          <a href="physHP.php" class="app-brand-link">
            <span class="app-brand-logo demo">
              <a href="physHP.php"><img src="assets/img/homelogo.png" alt="" class="img-fluid" width="80"></a>
            </span>
            <span class="app-brand-text demo menu-text fw-bold ms-2" style=" text-transform: none;">DiA</span>
          </a>

          <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
          </a>
        </div>

        <div class="menu-inner-shadow"></div>

        <ul class="menu-inner py-1">

          <!-- profile -->
          <li class="menu-item active open">
            <a href="physHP.php" class="menu-link">
              <i class="menu-icon tf-icons bx bx-home-circle"></i>
              <div data-i18n="Dashboards">Dashboard</div>
            </a>
          </li>
          <li class="menu-item">
            <a href="physProfile.php" class="menu-link ">
              <i class="menu-icon tf-icons bx bx-user"></i>
              <div data-i18n="Users">Profile</div>
            </a>
          </li>


          <li class="menu-header small text-uppercase">
            <span class="menu-header-text">our services</span>
          </li>

          <!-- services -->
          <li class="menu-item">
            <a href="Compare.php" class="menu-link ">
              <i class="menu-icon tf-icons bx bx-git-compare"></i>
              <div data-i18n="Compare">Compare AI Models</div>
            </a>
          </li>

          <li class="menu-header small text-uppercase">
            <span class="menu-header-text">other</span>
          </li>

          <!-- other -->
          <li class="menu-item">
            <a href="physLogout.php" class="menu-link ">
              <i class="menu-icon tf-icons bx bx-power-off me-2"></i>
              <div data-i18n="LogOut">Log Out</div>
            </a>
          </li>
        </ul>
      </aside>
      <!-- / Menu -->

      <!-- Layout container -->
      <div class="layout-page">
        <!-- Content wrapper -->
        <div class="content-wrapper">
          <!-- Content -->

          <div class="container-xxl flex-grow-1 container-p-y">
            <!-- Layout Demo -->
            <div class="layout-demo-wrapper">
              <div class="layout-demo-placeholder">

              </div>

              <div class="layout-demo-info">

              </div>
            </div>
            <!--/ Layout Demo -->

            <!-- Striped Rows -->
            <div class="card">
              <h5 class="card-header">My Patients</h5>
              <hr class="my-0">
              <div class="table-responsive text-nowrap">
                <table class="table table-striped">
                <caption class="ms-4"><a href="AddPatient.php">+ Add Patient</a></caption>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Date Of Birth</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody class="table-border-bottom-0">
                    <tr>
                                    <?php
                                
// Database connection

                                    $servername = "localhost";
                                    $username = "root";
                                    $password = "root";
                                    $dbname = "ADPrediction";

// Create connection
                                    $conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }
                                    if (isset($_SESSION['email'])) {
                                        $er = $_SESSION['email'];
                                        $e = "SELECT physiologistId FROM physiologist where email='$er'";
                                        $p = $conn->query($e);
                                        if ($p->num_rows > 0) {
                                            $ro = $p->fetch_assoc(); // Fetch the row from the result
                                            $phys = $ro['physiologistId']; // Get the value of 'physiologistId' column
                                            $sql = "SELECT * FROM patient where physiologist='$phys'";
                                            $result = $conn->query($sql);

// Display patient data in a table
                                            if ($result->num_rows > 0) {

                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $row["PatientID"] . "</td>";
                                                    echo "<td>" . $row["FirstName"] . " " . $row["LastName"] . "</td>";
                                                    echo "<td>" . $row["DOB"] . "</td>";
                                                    echo"<td>";
                                                    echo'<div class="dropdown">';
                                                    echo'<button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button>';
                                                    echo '<div class="dropdown-menu">';
                                                    echo '<a class="dropdown-item" href="setPatientID.php?id=' . $row["PatientID"] . '"><i class="bx bx-edit-alt me-1"></i> View</a>';
                                                    echo'<a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>';
                                                    echo' </div>';
                                                    echo' </div>';
													
													
                                                }

                                            } else {
                                                 echo "<tr>";
                                                  echo "<td colspan='4' style='text-align:center;'>";
                                                echo "You haven't added any patients";
                                                 echo "</td>";
                                                 echo "</tr>";
                                             
                                            }
                                        }
                                    }
// Close connection
                                    $conn->close();
                                    ?>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <!--/ Striped Rows -->
            
          </div>
          <!-- / Content -->

          <!-- Footer -->
          <footer class="content-footer footer bg-footer-theme">
            <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
              <div class="mb-2 mb-md-0">
                &copy; Copyright DiA. All Rights Reserved
              </div>
              <div class="d-none d-lg-inline-block">
                <a href="contact.php" target="_blank" class="footer-link">Contact</a>
              </div>
            </div>
          </footer>
          <!-- / Footer -->

          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->
      </div>
      <!-- / Layout page -->
    </div>

    <!-- / Layout wrapper -->
  </div>
  
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->

    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/perfect-scrollbar.js"></script>
    <script src="assets/js/menu.js"></script>

    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="assets/js/main2.js"></script>

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
</body>

</html>