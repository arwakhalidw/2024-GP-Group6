<?php
session_start();
if (isset($_GET['id'])) {
    $_SESSION['PatientID'] = $_GET['id'];
    header("Location: physViewPatient.php"); 
    exit();
} else {
    echo "Invalid patient ID.";
}
?>
