<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['otp_verified']) && $_POST['otp_verified'] === 'true') {
        $_SESSION['otp_verified'] = true;
        echo "OTP verified session set.";
    } else {
        echo "Invalid request.";
    }
}
?>
