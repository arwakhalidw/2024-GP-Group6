<?php
session_start();

// Check if the user is logged in and their role is patient
				if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') {
				echo '<script>alert("You are not authorized to access this page."); window.location.href = "index.php";</script>';
			    exit; 
									}
									
									
								
?>


<!DOCTYPE html>

<html lang="en" class="light-style layout-menu-fixed layout-compact" dir="ltr" data-theme="theme-default" data-assets-path="assets/" data-template="vertical-menu-template-free">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

  <title>Home</title>

  <meta name="description" content="" />


  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />

  <link rel="stylesheet" href="assets/vendor/boxicons/css/boxicons.css" />

  <!-- Core CSS -->
  <link rel="stylesheet" href="assets/vendor/core.css" class="template-customizer-core-css" />
  <link rel="stylesheet" href="assets/vendor/theme-default.css" class="template-customizer-theme-css" />
  <link rel="stylesheet" href="assets/css/demo.css" />

  <!-- Vendors CSS -->
  <link rel="stylesheet" href="assets/perfect-scrollbar.scss" />
  <link rel="stylesheet" href="assets/vendor/apex-charts.css" />

  <!-- Page CSS -->

  <!-- Helpers -->
  <script src="assets/vendor/helpers.js"></script>
  <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
  <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
  <script src="assets/js/config.js"></script>
</head>

<body>
  <!-- Layout wrapper -->
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
      <!-- Menu -->

      <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
        <div class="app-brand demo">
          <a href="patientHP.php" class="app-brand-link">
            <span class="app-brand-logo demo">
              <a href="patientHP.php"><img src="assets/img/homelogo.png" alt="" class="img-fluid" width="80"></a>
            </span>
            <span class="app-brand-text demo menu-text fw-bold ms-2" style=" text-transform: none;">DiA</span>
          </a>

          <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
          </a>
        </div>

        <div class="menu-inner-shadow"></div>

        <ul class="menu-inner py-1">

          <!-- profile -->
          <li class="menu-item active open">
            <a href="patientHP.php" class="menu-link">
              <i class="menu-icon tf-icons bx bx-home-circle"></i>
              <div data-i18n="Dashboards">Dashboard</div>
            </a>
          </li>
          <li class="menu-item">
            <a href="patientProfile.php" class="menu-link ">
              <i class="menu-icon tf-icons bx bx-user"></i>
              <div data-i18n="Users">Profile</div>
            </a>
          </li>


          <li class="menu-header small text-uppercase">
            <span class="menu-header-text">our services</span>
          </li>

          <!-- services -->
          <li class="menu-item">
            <a href="chatbotinterface.php" class="menu-link ">
              <i class="menu-icon tf-icons bx bx-cube-alt"></i>
              <div data-i18n="Predict">DiA Chatbot</div>
            </a>
          </li>

          <li class="menu-header small text-uppercase">
            <span class="menu-header-text">other</span>
          </li>

          <!-- other -->
          <li class="menu-item">
            <a href="patientLogout.php" class="menu-link ">
              <i class="menu-icon tf-icons bx bx-power-off me-2"></i>
              <div data-i18n="LogOut">Log Out</div>
            </a>
          </li>
        </ul>
      </aside>
      <!-- / Menu -->

      <!-- Layout container -->
      <div class="layout-page">
        <!-- Content wrapper -->
        <div class="content-wrapper">
          <!-- Content -->

          <div class="container-xxl flex-grow-1 container-p-y">
            <!-- Layout Demo -->
            <div class="layout-demo-wrapper">
              <div class="layout-demo-placeholder">

              </div>

              <div class="layout-demo-info">

              </div>
            </div>
            <!--/ Layout Demo -->

            <div class="card">
            <!-- Striped Rows -->
            <div class="card">
              <h5 class="card-header">My CDR History</h5>
              <hr class="my-0">
              <div class="table-responsive text-nowrap">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Score</th>
                      <th>Date</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody class="table-border-bottom-0">
                    <tr>
                      <td>1</td>
                      <td>
                        0.5
                      </td>
                      <td>2023-02-01</td>
                      <td>
                        <div class="dropdown">
                          <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item" href="patientViewScore.php"><i class="bx bx-edit-alt me-1"></i> View</a>
                            <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <!--/ Striped Rows -->

            <hr>
            <!-- Expense Overview -->
            <div>
              <div class="card h-100">
                <div class="card-header">
                  <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item">
                      <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab" data-bs-target="#navs-tabs-line-card-income" aria-controls="navs-tabs-line-card-income" aria-selected="true">CDR scores</button>
                    </li>
                  </ul>
                </div>
                <div class="card-body px-0">
                  <div class="tab-content p-0">
                    <div class="tab-pane fade show active" id="navs-tabs-line-card-income" role="tabpanel">
                      <div class="d-flex p-4 pt-3">
                        <div>
                          <small class="text-muted d-block">Total tests</small>
                          <div class="d-flex align-items-center">
                            <h6 class="mb-0 me-1">1</h6>
                          </div>
                        </div>
                      </div>
                      <div id="incomeChart"></div>
                      <div class="d-flex justify-content-center pt-4 gap-2">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!--/ Expense Overview -->
          </div>
            <br>
            <!-- Striped Rows -->
            <div class="card">
              <h5 class="card-header">My Predictions History</h5>
              <hr class="my-0">
              <div class="table-responsive text-nowrap">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Result</th>
                      <th>Date</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody class="table-border-bottom-0">
                    <tr>
                      <td>1</td>
                      <td>
                        Not Demented
                      </td>
                      <td>2023-02-01</td>
                      <td>
                        <div class="dropdown">
                          <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item" href="patientViewPrediction.php"><i class="bx bx-edit-alt me-1"></i> View</a>
                            <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <!--/ Striped Rows -->


            <!-- Use this for when no predictions or CDR scores are found -->
            <!-- Striped Rows -->
            <!--
            <div class="card">
              <h5 class="card-header">My Predictions History</h5>
              <hr class="my-0">
              <div class="table-responsive text-nowrap">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Result</th>
                      <th>Date</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody class="table-border-bottom-0">
                    <tr>
                      <td colspan="4"> No Predictions or No CDR Scores</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            -->
            <!-- /Striped Rows -->

          </div>
          <!-- / Content -->

          <!-- Footer -->
          <footer class="content-footer footer bg-footer-theme">
            <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
              <div class="mb-2 mb-md-0">
                &copy; Copyright DiA. All Rights Reserved
              </div>
              <div class="d-none d-lg-inline-block">
                <a href="contact.php" target="_blank" class="footer-link">Contact</a>
              </div>
            </div>
          </footer>
          <!-- / Footer -->

          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->
      </div>
      <!-- / Layout page -->
    </div>

    <!-- / Layout wrapper -->
  </div>

  <!-- Core JS -->
  <!-- build:js assets/vendor/js/core.js -->

  <script src="assets/js/jquery.js"></script>
  <script src="assets/js/popper.js"></script>
  <script src="assets/js/bootstrap.js"></script>
  <script src="assets/js/perfect-scrollbar.js"></script>
  <script src="assets/js/menu.js"></script>

  <!-- endbuild -->

  <!-- Vendors JS -->
  <script src="assets/js/apexcharts.js"></script>
  <!-- Main JS -->
  <script src="assets/js/main2.js"></script>

  <!-- Page JS -->
  <script src="assets/js/dashboards-analytics.js"></script>

  <!-- Place this tag in your head or just before your close body tag. -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
</body>

</html>